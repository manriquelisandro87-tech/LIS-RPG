# LIS RPG — Página web v1

Esta es una primera versión estática de la página de LIS RPG.

## Archivos
- index.html — página principal
- style.css — diseño y colores
- script.js — botones provisionales

## Antes de publicarla
1. Cambiar el enlace del botón de descarga en `index.html`.
2. Cambiar el enlace de donación.
3. Reemplazar los enlaces de YouTube, TikTok, Discord e Instagram.
4. Si querés, agregar una imagen/panorama propio en `assets/` y modificar el fondo del `.hero` en `style.css`.

## Paleta
Rosa Sakura: #E8A6B8
Rosa claro: #F4D3DC
Verde oscuro: #263D35
Fondo: #111512
Dorado: #E3B85C
Crema: #F5EBDD
